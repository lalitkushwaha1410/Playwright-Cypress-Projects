export const constanttext = {
    rejectpopuptext: "You're about to reject this page. This will send it back for further review and notify the authors. ",
    afterrejectpopuptext: "The page was rejected",
    afterrejectpopuptitle: "Page rejected",
    afterpublishpopuptext: "The page has been successfully published to the platform.",
    publishpopuptext: "You're about to publish this page to the subscriber site. This will make the page publicly accessible to everyone. ",
    publishpopuptitle: "Publish Page",
    afterpublishpopuptitle: "Page published",
    beforereviewpopuptext: "Another user is currently editing this page.",
}