export const user = {
    reviewAccess: {
      username: "wf_reviewer@cha.rbxd.ds",
      password: "Passw0rd",
    },
    creatorAccess: {
      username: "SptCmsTestEditor@cha.rbxd.ds",
      password: "Passw0rd",
    },
    noAccess: {
      username: "wf_noaccess@cha.rbxd.ds",
      password: "Passw0rd",
    }

}