export const constanttext = {
    text: "Example Hello World",
    pricingURL: "https://authoring.staging.cha.rbxd.ds/content/pricing",
    
}