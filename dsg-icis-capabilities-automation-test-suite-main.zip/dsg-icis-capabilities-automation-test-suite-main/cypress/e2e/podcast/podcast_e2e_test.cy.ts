import { shared } from '../../fixtures/constants/shared';
import { Podcast } from '../../support/ui/pages/podcast.po';

describe('E2E Authoring and Subscriber Automation Test for Podcast Tool', { testIsolation: false }, () => {
  const podcastPage = new Podcast();
  var env = Cypress.env('ENV');

  beforeEach('Login into Authoring Site', () => {
    cy.viewport(1280, 720);
    cy.log('Running in ' + env + ' environment');
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.wait(20000);
  });

  // it('Validate Creating a new intelligence page', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   cy.url().should('include', 'authoring')
  //   cy.screenshot('Creating Intelligence Page');
  // });

  // it('Validate Adding a blank Podcast card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   podcastPage.clickAtContentBlockButton();
  //   cy.wait(1000);
  //   podcastPage.selectPodcastCard();
  //   cy.screenshot('Creating Blank Podcast Card');
  //   podcastPage.deleteContentBlock();
  // });

  // it('Validate Error Message for Invalid Podcast URL', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   podcastPage.clickAtContentBlockButton();
  //   cy.wait(1000);
  //   podcastPage.selectPodcastCard();
  //   podcastPage.clickOnAddPodcast();
  //   podcastPage.enterInvalidPodcastURL(shared.WrongPodcastURL_1);
  //   cy.screenshot('Validate Error Message for Invalid Podcast URL');
  //   cy.wait(1000);
  //   podcastPage.deleteContentBlock();
  // });

  // it('Validate able to add Minimal Podcast', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   podcastPage.clickAtContentBlockButton();
  //   cy.wait(1000);
  //   podcastPage.selectPodcastCard();
  //   podcastPage.clickOnAddPodcast();
  //   podcastPage.enterPodcastUrl();
  //   podcastPage.clickOnPopupNextButton();
  //   podcastPage.selectMinimalPodcast();
  //   podcastPage.validateMinimalPreviewPodcastScreen();
  //   podcastPage.clickOnPopupAddToPageButton();
  //   podcastPage.validateSavedMinimalPodcast();
  // });

  // it('Validate title section and Saving Title for the Podcast card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   //podcastPage.validatePodcastTitleHelpText();
  //   podcastPage.addTitleToPodcast();
  //   podcastPage.validateTitleSaved();
  //   cy.screenshot('Validate title section and Saving Title for the Podcast card');
  // });

  // it('Validate Footer section and Saving Footer notes for the Podcast card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   //podcastPage.validatePodcastFooterHelpText();
  //   podcastPage.addFooterToPodcast();
  //   podcastPage.validateFootnotesSaved();
  //   cy.screenshot('Validate Footer section and Saving Footer notes for the Podcast card');
  //   cy.wait(1000);
  // });

  //// This test case also cover the adding podcast to the authoring page
  it('Validat adding Minimal Podcast and verify edit button for noaccess user', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.clickAtContentBlockButton();
    cy.wait(1000);
    podcastPage.selectPodcastCard();
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.selectMinimalPodcast();
    podcastPage.validateMinimalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validateSavedMinimalPodcast();
    // Login with user with no access
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.noaccessUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
     cy.get('a').contains('Mercury E2E Test').click();
         // Check if the edit button is not visible
    podcastPage.verifyeditbuttonvisibility();
    cy.screenshot('Validate edit button visibility for different user');
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.sendForReviewPage();
    cy.wait(8000);
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // Subscriber view test validations

  // it('Login into Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   var env = Cypress.env('ENV');
  //   cy.log('Running in ' + env + 'environment');
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.screenshot('Login into Subscriber View');
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  // });

  // it('Navigating to Intelligence Page in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   cy.screenshot('Navigating to Intelligence Page in Subscriber View');
  //   podcastPage.openIntelligencePage();
  // });

  it('Validate Minimal Podcast in the Subscriber View', () => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.CheckDuplicateLogin();
    podcastPage.openIntelligencePage();
    podcastPage.findMinimalPodcastInSubscriber();
    cy.screenshot('Validate Minimal Podcast in the Subscriber View');
  });

  // it('Validate Title and Footnotes for Podcast in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   podcastPage.openIntelligencePage();
  //   podcastPage.validateTitleInSubscriberView();
  //   podcastPage.validateFootnotesInSubscriberView();
  //   cy.screenshot('Validate Title and Footnotes for Podcast in Subscriber View');
  // });

  it('Delete Intelligence Page', () => {
    podcastPage.DeleteRecord();
  });
});
