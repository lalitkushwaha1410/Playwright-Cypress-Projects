import { shared } from '../../fixtures/constants/shared';
import { VideoPage } from '../../support/ui/pages/video.po';

describe('Component Test for Video card', { testIsolation: false }, () => {
  const videoPage = new VideoPage();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    const env = Cypress.env('ENV');
    cy.log('Running in' + env + 'environment');
    cy.visit(shared.environment.video_testHarness[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
    cy.waitForVisible('button[data-testid^="Add__Video"]', 15000);
  });

  it('Validate Error Message for Invalid Video URL', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterInvalidVideoURL();
    cy.screenshot('Validate Error Message for Invalid Video URL');
    cy.wait(1000);
    cy.get('button').contains('Cancel').should('be.visible').click();
    cy.wait(1000);
  });

  it('Validate Error Message for Typo Error in Video URL', () => {
    videoPage.clickOnAddVideo();
    videoPage.entertypoErrroVideoURL();
    cy.screenshot('Validate Error Message for Typo Error');
    cy.wait(1000);
    cy.get('button').contains('Cancel').should('be.visible').click();
    cy.wait(1000);
  });

  it('Validate Preview for Video and Add Video to Page', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    cy.screenshot('Validate Video added to Page');
  });

  it('Validate title section and Saving Title for the Video card', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    //videoPage.validateVideoTitlePlacehoder();
    //videoPage.validateVideoTitleHelpText();
    videoPage.addHeaderToVideo();
    videoPage.validateTitleSaved();
    cy.screenshot('Validate Title added for Video Card');
  });

  it('Validate Footer section and Saving Footer notes for the Video card', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
   // videoPage.validateVideoFooterPlaceholder();
   // videoPage.validateVideoFooterHelpText();
    videoPage.addFooterToVideo();
    videoPage.validateFootnotesSaved();
    cy.screenshot('Validate Footnotes added for Video Card');
  });

  it.skip('Validate the Video saved in pause mode and once played user should able to edit the play settings', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    videoPage.playSavedVideo();
    videoPage.validatePlayVideoScreenDisplay();
    videoPage.mouseHoverVideoAndPauseVideo();
    videoPage.validateVideoQualityChangeIcon();
    videoPage.validateVideoVolumeChangeIcon();
    videoPage.validateVideoFullScreenIcon();
  });


  it('Switching to Subscriber view', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    videoPage.addHeaderToVideo();
    videoPage.addFooterToVideo();
    videoPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Switching to Subscriber view');
  });

  it('Validate Video title and Footer in Subscriber View', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    videoPage.addHeaderToVideo();
    videoPage.addFooterToVideo();
    videoPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    videoPage.validatetitleInSubscriberView();
    videoPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Video title and Footer in Subscriber View');
  });

  it('Validate Video in Subscriber View', () => {
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    videoPage.addHeaderToVideo();
    videoPage.addFooterToVideo();
    videoPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    videoPage.findVideoInSubscriber();
    cy.screenshot('Validate Video in Subscriber View');
    cy.wait(1000);
  });


});
