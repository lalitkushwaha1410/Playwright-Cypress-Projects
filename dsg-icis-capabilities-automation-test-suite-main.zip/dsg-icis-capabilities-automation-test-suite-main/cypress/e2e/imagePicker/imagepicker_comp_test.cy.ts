import { shared } from '../../fixtures/constants/shared';
import { ImagePickerModal } from '../../support/ui/pages/imagePicker.po';
describe('Component Test for Image picker', { testIsolation: false }, () => {
  const imagePicker = new ImagePickerModal();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });
  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    const env = Cypress.env('ENV');
    cy.visit(shared.environment.imagePilet_testHarness[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
    cy.waitForVisible('button:contains("Choose Featured Image")', 15000);
  });


  it('Validate adding a featured image from image picker', () => {
    cy.screenshot('before clicking on choose featured image button');
    imagePicker.clickChooseFeaturedImageButton();
    imagePicker.validateImagePickerModalTitle();
    cy.wait(4000);
    imagePicker.selectFeaturedImage();
    imagePicker.clickOnPreviewButton();
    imagePicker.validatePrivewModalTitle();
    imagePicker.validateBackButtonisVisible();
    imagePicker.clickAddToHeaderButton();
    cy.wait(3000);
    imagePicker.validatePreviewdImageIsDisplayed();
    cy.screenshot('Validate adding a featured image from image picker');
  });

});